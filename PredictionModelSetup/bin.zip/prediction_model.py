# -*- coding: utf-8 -*-

import pandas as pd
from pycaret.regression import load_model, predict_model
from fastapi import FastAPI
import uvicorn
from pydantic import create_model
from pandas.tseries.offsets import DateOffset
import holidays
from sys import argv

from a2wsgi import ASGIMiddleware

app = FastAPI()
wsgi_app = ASGIMiddleware(app)

# Load trained Pipeline
model = load_model("api_v1")

input_model = create_model("api_v1_input",
                        **{'From': "20180403", 'To': "20180607", 'DeviceId': '533PM-1ACBA'})

output_model = create_model("api_v1_output", 
                time=['2018-03-04T00:00:00.000000000', '2018-03-04T00:10:00.000000000'], 
                prediction_values=[129.911747, 129.911747])

"""
input_user_data = {"From": "20180403", 
                    "To": "20180607",
                    "DeviceId": '533PM-1ACBA'}
"""

winter_months = [10, 11, 12, 1, 2, 3] # 0
summer_months = [4, 5, 6, 7, 8, 9] # 1

winter_summer_model = pd.read_excel("winter_summer_model.xlsx")

# @app.post("/predict", response_model=output_model)
@app.post("/predict")
def predict(data: input_model):
    from_date = pd.to_datetime(data.From, format="%Y%m%d")
    to_date = pd.to_datetime(data.To, format="%Y%m%d") + DateOffset(days=1)

    # create data set with 10 min resolution
    times = pd.Series(pd.date_range(start=from_date, 
                                    end=to_date, freq="min")).iloc[::10].iloc[0:-1]

    df = pd.DataFrame()
    df["time"] = times
    df["device"] = data.DeviceId

    # Get holidays
    hu_holidays = holidays.HU()
    df["is_holiday"] = False
    df.loc[df["time"].apply(lambda d: d in hu_holidays), "is_holiday"] = True

    df["month"] = df["time"].dt.month
    df["weekday"] = df["time"].dt.weekday
    df["hour"] = df["time"].dt.hour
    df["minute"] = df["time"].dt.minute

    df["winter_summer"] = 0
    df.loc[df["month"].isin(summer_months), "winter_summer"] = 1

    # Get power from winter-summer calculation
    df = df.merge(winter_summer_model, 
                  how="left", on=["weekday", "hour", "minute", "is_holiday", 
                                  "device", "winter_summer"])

    predictions = predict_model(model, data=df)
    times = predictions["time"].to_list()
    values = predictions["prediction_label"].to_list()

    return [
        {"time" : times[i], "value" : values[i]} for i in range(len(times))
    ]
    
    
if __name__ == "__main__":
     port = int(argv[1])
     uvicorn.run(app, host="0.0.0.0", port=port)